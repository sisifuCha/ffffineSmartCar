"""融合雷达 + YOLO 视觉的沿墙建图决策。"""

from __future__ import annotations

import math
from typing import Any, Dict, Optional


class WallPlanner:
    """输出离散动作，映射到 car_protocol 前后左右。"""

    def __init__(
        self,
        follow_side: str = "right",
        target_dist_m: float = 0.4,
        target_wall_px: float = 120.0,
        front_stop_m: float = 0.35,
        front_slow_m: float = 0.6,
    ) -> None:
        self.follow_side = follow_side
        self.target_dist_m = target_dist_m
        self.target_wall_px = target_wall_px
        self.front_stop_m = front_stop_m
        self.front_slow_m = front_slow_m
        self.step = 0

    def _lidar_sectors(self, scan: dict[str, Any]) -> dict[str, Optional[float]]:
        ranges = scan.get("ranges", [])
        if not ranges:
            return {"front": None, "side": None}
        angle_min = float(scan.get("angle_min", 0))
        inc = float(scan.get("angle_increment", 0))
        rmax = float(scan.get("range_max", 8))

        def sector(lo_deg: float, hi_deg: float) -> Optional[float]:
            lo, hi = math.radians(min(lo_deg, hi_deg)), math.radians(max(lo_deg, hi_deg))
            best = None
            ang = angle_min
            for r in ranges:
                if 0.05 < r < rmax and lo <= ang <= hi:
                    best = r if best is None else min(best, r)
                ang += inc
            return best

        if self.follow_side == "right":
            side = sector(-110, -70)
        else:
            side = sector(70, 110)
        front = sector(-30, 30)
        return {"front": front, "side": side}

    def decide(
        self,
        scan: Optional[dict[str, Any]],
        vision: Optional[dict[str, Any]],
    ) -> Dict[str, Any]:
        vis = vision or {}
        sectors = self._lidar_sectors(scan) if scan else {"front": None, "side": None}
        front_m = sectors["front"]
        side_m = sectors["side"]
        follow = float(vis.get("follow_wall", 0))
        front_v = float(vis.get("front_wall", 0))
        corner = vis.get("corner_hint", "none")
        wall_px = vis.get("wall_dist_px")
        side_cn = "右" if self.follow_side == "right" else "左"

        # 1) 雷达前方障碍
        if front_m is not None and front_m < self.front_stop_m:
            turn = "TURN_LEFT" if self.follow_side == "right" else "TURN_RIGHT"
            self.step += 1
            return self._plan(turn, f"第{self.step}步：雷达前方 {front_m:.2f}m — 原地转弯")

        # 2) 视觉墙角
        if corner == "concave" or front_v > 0.55:
            turn = "TURN_LEFT" if self.follow_side == "right" else "TURN_RIGHT"
            self.step += 1
            return self._plan(turn, f"第{self.step}步：视觉检测到墙角 — 转弯 90°")

        # 3) 离墙距离（视觉像素 + 雷达米）
        if wall_px is not None:
            if wall_px < self.target_wall_px * 0.6:
                turn = "TURN_LEFT" if self.follow_side == "right" else "TURN_RIGHT"
                return self._plan(turn, f"离{side_cn}墙太近 — 微调转弯")
            if wall_px > self.target_wall_px * 1.8 and follow < 0.2:
                turn = "TURN_RIGHT" if self.follow_side == "right" else "TURN_LEFT"
                return self._plan(turn, f"离{side_cn}墙太远 — 转向找墙")

        if side_m is not None:
            if side_m < self.target_dist_m * 0.6:
                turn = "TURN_LEFT" if self.follow_side == "right" else "TURN_RIGHT"
                return self._plan(turn, f"雷达：离墙 {side_m:.2f}m 太近")
            if side_m > self.target_dist_m * 2.0 and follow < 0.15:
                turn = "TURN_RIGHT" if self.follow_side == "right" else "TURN_LEFT"
                return self._plan(turn, f"雷达：侧墙丢失 — 转向找墙")

        # 4) 前方偏近 — 慢速前进
        if front_m is not None and front_m < self.front_slow_m:
            return self._plan("FORWARD_SLOW", f"前方 {front_m:.2f}m — 慢速沿{side_cn}墙前进")
        if front_v > 0.42:
            return self._plan("FORWARD_SLOW", "视觉前方偏近 — 慢速前进")

        # 5) 正常沿墙
        if follow >= 0.12 or (side_m is not None and 0.25 < side_m < 0.8):
            return self._plan("FORWARD", f"沿{side_cn}墙前进，保持约 {self.target_dist_m}m")

        turn = "TURN_RIGHT" if self.follow_side == "right" else "TURN_LEFT"
        return self._plan(turn, f"{side_cn}侧墙信号弱 — 小幅转向找墙")

    def _plan(self, action: str, guide_cn: str) -> Dict[str, Any]:
        return {
            "action": action,
            "guide_cn": guide_cn,
            "follow_side": self.follow_side,
            "move_forward": action in ("FORWARD", "FORWARD_SLOW"),
        }
