"""占用栅格 SLAM（PC 端本地建图）。"""

from __future__ import annotations

import math
from typing import Any, Optional


class OccupancySlam:
    def __init__(self, resolution: float = 0.05, map_size_m: float = 24.0) -> None:
        self.resolution = resolution
        self.size = int(map_size_m / resolution)
        self.origin = self.size // 2
        self.grid = [[0.5] * self.size for _ in range(self.size)]
        self.pose = {"x": 0.0, "y": 0.0, "theta": 0.0}
        self._log_odds_hit = 0.85
        self._log_odds_miss = -0.4

    def update_odom(self, odom: dict[str, Any]) -> None:
        self.pose["x"] = float(odom.get("x", 0))
        self.pose["y"] = float(odom.get("y", 0))
        self.pose["theta"] = float(odom.get("theta", 0))

    def update_scan(self, scan: dict[str, Any]) -> None:
        px = self.pose["x"]
        py = self.pose["y"]
        th = self.pose["theta"]
        ranges = scan.get("ranges", [])
        angle_min = float(scan.get("angle_min", 0))
        angle_inc = float(scan.get("angle_increment", 0))
        rmax = float(scan.get("range_max", 8.0))

        for i, r in enumerate(ranges):
            if r <= 0.05 or r >= rmax:
                continue
            ang = angle_min + i * angle_inc
            wx = px + r * math.cos(th + ang)
            wy = py + r * math.sin(th + ang)
            self._ray(px, py, wx, wy)

    def _ray(self, x0: float, y0: float, x1: float, y1: float) -> None:
        sx, sy = self._w2g(x0, y0)
        gx, gy = self._w2g(x1, y1)
        steps = max(abs(gx - sx), abs(gy - sy), 1)
        for s in range(steps):
            t = s / steps
            ix = int(sx + (gx - sx) * t)
            iy = int(sy + (gy - sy) * t)
            if 0 <= ix < self.size and 0 <= iy < self.size:
                self._mark(ix, iy, self._log_odds_miss)
        if 0 <= gx < self.size and 0 <= gy < self.size:
            self._mark(gx, gy, self._log_odds_hit)

    def _w2g(self, x: float, y: float) -> tuple[float, float]:
        return self.origin + x / self.resolution, self.origin - y / self.resolution

    def _mark(self, x: int, y: int, delta: float) -> None:
        v = self.grid[y][x] + delta * 0.05
        self.grid[y][x] = max(0.01, min(0.99, v))

    def to_png_bytes(self) -> bytes:
        import io
        from PIL import Image

        img = Image.new("RGB", (self.size, self.size), (30, 30, 30))
        px = img.load()
        for y in range(self.size):
            for x in range(self.size):
                v = self.grid[y][x]
                if v < 0.35:
                    c = (240, 240, 240)
                elif v > 0.65:
                    c = (40, 40, 40)
                else:
                    c = (128, 128, 128)
                px[x, y] = c
        # robot
        rx, ry = self._w2g(self.pose["x"], self.pose["y"])
        ix, iy = int(rx), int(ry)
        if 0 <= ix < self.size and 0 <= iy < self.size:
            for dx in (-1, 0, 1):
                for dy in (-1, 0, 1):
                    if 0 <= ix + dx < self.size and 0 <= iy + dy < self.size:
                        px[ix + dx, iy + dy] = (255, 80, 80)
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        return buf.getvalue()

    def frontier_count(self) -> int:
        n = 0
        for y in range(1, self.size - 1):
            for x in range(1, self.size - 1):
                if 0.45 < self.grid[y][x] < 0.55:
                    for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                        if self.grid[y + dy][x + dx] < 0.35:
                            n += 1
                            break
        return n
