"""YOLO + OpenCV 墙体识别（Windows 端）。"""

from __future__ import annotations

import math
from typing import Any, Dict, List, Optional, Tuple

import cv2
import numpy as np

CUSTOM_CLASSES = {"wall", "railing"}


class WallVisionAnalyzer:
    def __init__(
        self,
        yolo_weights: Optional[str] = None,
        conf_threshold: float = 0.35,
        min_wall_score: float = 0.12,
    ) -> None:
        self.yolo_weights = yolo_weights
        self.conf_threshold = conf_threshold
        self.min_wall_score = min_wall_score
        self._yolo = None
        self._yolo_ok = False
        self._class_names: Dict[int, str] = {}
        self._prev_side: Optional[float] = None

    def ensure_yolo(self) -> None:
        if self._yolo_ok or not self.yolo_weights:
            return
        try:
            from ultralytics import YOLO
            self._yolo = YOLO(self.yolo_weights)
            self._yolo_ok = True
            self._class_names = {int(k): v for k, v in (self._yolo.names or {}).items()}
        except Exception as exc:
            print(f"[vision] YOLO load failed, OpenCV only: {exc}")

    @staticmethod
    def _region_score(gray: np.ndarray, x0: int, x1: int) -> float:
        roi = gray[:, x0:x1]
        if roi.size == 0:
            return 0.0
        edges = cv2.Canny(cv2.GaussianBlur(roi, (5, 5), 0), 40, 120)
        vert = cv2.Sobel(roi, cv2.CV_64F, 1, 0, ksize=3)
        return min(1.0, float(np.mean(np.abs(vert))) / 35.0 * 0.7 + float(np.mean(edges > 0)) * 0.3)

    def _yolo_regions(self, frame: np.ndarray) -> Tuple[float, float, float, float, List]:
        if not self._yolo_ok or self._yolo is None:
            return 0.0, 0.0, 0.0, 0.0, []
        left = right = front = rail = 0.0
        boxes = []
        h, w = frame.shape[:2]
        try:
            for box in self._yolo(frame, verbose=False, conf=self.conf_threshold)[0].boxes:
                cls_id = int(box.cls[0])
                name = self._class_names.get(cls_id, "")
                x1, y1, x2, y2 = [int(v) for v in box.xyxy[0].tolist()]
                conf = float(box.conf[0])
                cx = (x1 + x2) / 2 / w
                boxes.append({"label": name, "conf": conf, "xyxy": [x1, y1, x2, y2]})
                weight = conf * min(1.0, (y2 - y1) / max(h * 0.3, 1))
                if name in CUSTOM_CLASSES:
                    if cx < 0.33:
                        left = max(left, weight)
                    elif cx > 0.66:
                        right = max(right, weight)
                    else:
                        front = max(front, weight)
                    if name == "railing":
                        rail = max(rail, weight)
        except Exception:
            pass
        return left, right, front, rail, boxes

    def analyze(self, frame: np.ndarray, follow_side: str = "right") -> Dict[str, Any]:
        self.ensure_yolo()
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        h, w = gray.shape
        t = w // 3
        lc = self._region_score(gray, 0, t)
        rc = self._region_score(gray, w - t, w)
        fc = self._region_score(gray, t, w - t)
        yl, yr, yf, yrail, boxes = self._yolo_regions(frame)
        left = min(1.0, lc + yl * 0.75)
        right = min(1.0, rc + yr * 0.75)
        front = min(1.0, fc + yf * 0.75)
        side_score = right if follow_side == "right" else left
        corner = "none"
        if front > 0.45 and side_score > self.min_wall_score:
            corner = "concave"
        elif self._prev_side is not None and self._prev_side - side_score > 0.18:
            corner = "convex"
        self._prev_side = side_score

        # 估算侧墙像素距离（右墙）
        wall_dist_px = self._estimate_wall_distance(frame, follow_side)

        return {
            "valid": max(left, right, front) >= self.min_wall_score,
            "left_wall": round(left, 3),
            "right_wall": round(right, 3),
            "front_wall": round(front, 3),
            "follow_wall": round(side_score, 3),
            "wall_dist_px": wall_dist_px,
            "corner_hint": corner,
            "suggested_side": follow_side,
            "yolo_active": self._yolo_ok,
            "boxes": boxes,
        }

    @staticmethod
    def _estimate_wall_distance(frame: np.ndarray, side: str) -> Optional[float]:
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        h, w = gray.shape
        if side == "right":
            roi = gray[:, int(w * 0.5):]
            col_weights = np.mean(cv2.Canny(roi, 50, 150), axis=0)
        else:
            roi = gray[:, : int(w * 0.5)]
            col_weights = np.mean(cv2.Canny(roi, 50, 150), axis=0)
        if col_weights.size == 0 or col_weights.max() < 10:
            return None
        idx = int(np.argmax(col_weights))
        return float(idx if side == "left" else roi.shape[1] - idx)

    @staticmethod
    def draw_overlay(frame: np.ndarray, vis: Dict[str, Any], plan: Dict[str, Any]) -> np.ndarray:
        out = frame.copy()
        for box in vis.get("boxes", []):
            x1, y1, x2, y2 = box["xyxy"]
            cv2.rectangle(out, (x1, y1), (x2, y2), (0, 200, 0), 2)
            cv2.putText(out, f"{box['label']} {box['conf']:.2f}", (x1, y1 - 4),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0, 200, 0), 1)
        action = plan.get("action", "STOP")
        msg = plan.get("guide_cn", "")
        cv2.putText(out, f"ACTION: {action}", (10, 24), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)
        cv2.putText(out, msg[:60], (10, 52), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
        dist = vis.get("wall_dist_px")
        if dist is not None:
            cv2.putText(out, f"wall_dist_px={dist:.0f}", (10, 76),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)
        return out
