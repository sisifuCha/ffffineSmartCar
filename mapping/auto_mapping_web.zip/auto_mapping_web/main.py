#!/usr/bin/env python3
"""
Windows PC 自动建图 Web 服务

- 接收小车推送 @SCAN/@ODOM (6603)
- 拉取小车视频 http://car:6500/video_feed
- YOLO 识别墙体 + 雷达 SLAM
- 下发 $...# 控制小车前后左右

用法:
  pip install -r requirements.txt
  copy config.yaml.example config.yaml   # 编辑 car.ip
  python main.py
  浏览器 http://127.0.0.1:8080
"""

from __future__ import annotations

import asyncio
import json
import logging
import threading
import time
from pathlib import Path
from typing import Any, Optional

import cv2
import numpy as np
import yaml
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse, Response

from car_client import CarClient
from slam_map import OccupancySlam
from vision_analyzer import WallVisionAnalyzer
from wall_planner import WallPlanner

ROOT = Path(__file__).resolve().parent
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("auto_mapping_web")

app = FastAPI(title="Auto Mapping Web")


class AppState:
    def __init__(self, cfg: dict[str, Any]) -> None:
        car = cfg.get("car", {})
        mapping = cfg.get("mapping", {})
        vision = cfg.get("vision", {})
        control = cfg.get("control", {})

        self.car_ip = car.get("ip", "192.168.27.221")
        self.video_port = int(car.get("video_http_port", 6500))
        self.car_type = int(car.get("car_type", 1))
        self.sensor_port = int(cfg.get("server", {}).get("sensor_listen_port", 6603))
        self.command_interval = int(control.get("command_interval_ms", 200)) / 1000.0

        self.slam = OccupancySlam(
            resolution=float(mapping.get("resolution", 0.05)),
            map_size_m=float(mapping.get("map_size_m", 24)),
        )
        self.vision = WallVisionAnalyzer(
            yolo_weights=vision.get("yolo_weights"),
            conf_threshold=float(vision.get("conf_threshold", 0.35)),
        ) if vision.get("enabled", True) else None
        self.planner = WallPlanner(
            follow_side=vision.get("follow_side", "right"),
            target_wall_px=float(vision.get("target_wall_px", 120)),
        )
        self.car = CarClient(
            self.car_ip,
            int(car.get("control_tcp_port", 6000)),
            self.car_type,
        )

        self.latest_scan: Optional[dict] = None
        self.latest_odom: Optional[dict] = None
        self.latest_vision: dict = {}
        self.latest_plan: dict = {"action": "STOP", "guide_cn": "等待启动"}
        self.latest_frame_jpeg: Optional[bytes] = None
        self.auto_running = bool(control.get("auto_start", False))
        self.scan_count = 0
        self._lock = threading.Lock()
        self._clients: set[WebSocket] = set()

    def parse_sensor(self, msg: str) -> None:
        msg = msg.strip()
        if msg.startswith("@SCAN") and msg.endswith("#"):
            data = json.loads(msg[5:-1])
            with self._lock:
                self.latest_scan = data
                self.scan_count += 1
                if self.latest_odom:
                    self.slam.update_odom(self.latest_odom)
                self.slam.update_scan(data)
        elif msg.startswith("@ODOM") and msg.endswith("#"):
            with self._lock:
                self.latest_odom = json.loads(msg[5:-1])

    def control_tick(self) -> None:
        if not self.auto_running:
            return
        with self._lock:
            scan = self.latest_scan
            vis = self.latest_vision
        plan = self.planner.decide(scan, vis)
        with self._lock:
            self.latest_plan = plan
        self.car.send_action(plan["action"])

    def video_tick(self) -> None:
        if self.vision is None:
            return
        url = f"http://{self.car_ip}:{self.video_port}/video_feed"
        cap = cv2.VideoCapture(url)
        if not cap.isOpened():
            logger.warning("video open failed: %s", url)
            return
        logger.info("video stream connected: %s", url)
        while True:
            ok, frame = cap.read()
            if not ok:
                time.sleep(0.5)
                continue
            vis = self.vision.analyze(frame, self.planner.follow_side)
            with self._lock:
                plan = dict(self.latest_plan)
                self.latest_vision = vis
            overlay = self.vision.draw_overlay(frame, vis, plan)
            _, buf = cv2.imencode(".jpg", overlay, [int(cv2.IMWRITE_JPEG_QUALITY), 75])
            with self._lock:
                self.latest_frame_jpeg = buf.tobytes()
            time.sleep(0.08)


STATE: Optional[AppState] = None


def get_state() -> AppState:
    global STATE
    if STATE is None:
        cfg_path = ROOT / "config.yaml"
        if not cfg_path.exists():
            cfg_path = ROOT / "config.yaml.example"
        with cfg_path.open("r", encoding="utf-8") as fp:
            STATE = AppState(yaml.safe_load(fp))
    return STATE


async def sensor_ws_server() -> None:
    import websockets

    st = get_state()
    host = "0.0.0.0"
    port = st.sensor_port

    async def handler(ws: Any) -> None:
        logger.info("car sensor connected from %s", ws.remote_address)
        try:
            async for raw in ws:
                st.parse_sensor(raw)
        except Exception as exc:
            logger.warning("sensor ws closed: %s", exc)

    async with websockets.serve(handler, host, port, ping_interval=20):
        logger.info("sensor listener ws://%s:%s", host, port)
        await asyncio.Future()


async def control_loop() -> None:
    st = get_state()
    while True:
        try:
            st.control_tick()
        except Exception as exc:
            logger.warning("control error: %s", exc)
        await asyncio.sleep(st.command_interval)


@app.on_event("startup")
async def startup() -> None:
    st = get_state()
    threading.Thread(target=st.video_tick, daemon=True).start()
    asyncio.create_task(sensor_ws_server())
    asyncio.create_task(control_loop())
    cfg_path = ROOT / "config.yaml"
    if not cfg_path.exists():
        cfg_path = ROOT / "config.yaml.example"
    with cfg_path.open("r", encoding="utf-8") as fp:
        port = int(yaml.safe_load(fp).get("server", {}).get("port", 8080))
    logger.info("web UI http://127.0.0.1:%s", port)


@app.get("/", response_class=HTMLResponse)
async def index() -> HTMLResponse:
    html = (ROOT / "templates" / "index.html").read_text(encoding="utf-8")
    return HTMLResponse(html)


@app.get("/api/status")
async def api_status() -> dict[str, Any]:
    st = get_state()
    with st._lock:
        return {
            "auto_running": st.auto_running,
            "scan_count": st.scan_count,
            "pose": st.slam.pose,
            "plan": st.latest_plan,
            "vision": st.latest_vision,
            "frontier": st.slam.frontier_count(),
            "car_ip": st.car_ip,
        }


@app.post("/api/start")
async def api_start() -> dict[str, str]:
    st = get_state()
    st.auto_running = True
    st.car.connect()
    return {"status": "started"}


@app.post("/api/stop")
async def api_stop() -> dict[str, str]:
    st = get_state()
    st.auto_running = False
    st.car.stop()
    return {"status": "stopped"}


@app.get("/map.png")
async def map_png() -> Response:
    st = get_state()
    return Response(st.slam.to_png_bytes(), media_type="image/png")


@app.get("/video.jpg")
async def video_jpg() -> Response:
    st = get_state()
    with st._lock:
        data = st.latest_frame_jpeg
    if not data:
        # 1x1 placeholder
        return Response(b"", media_type="image/jpeg", status_code=204)
    return Response(data, media_type="image/jpeg")


@app.websocket("/ws/ui")
async def ws_ui(ws: WebSocket) -> None:
    await ws.accept()
    st = get_state()
    st._clients.add(ws)
    try:
        while True:
            with st._lock:
                payload = {
                    "scan_count": st.scan_count,
                    "pose": st.slam.pose,
                    "plan": st.latest_plan,
                    "vision": {
                        k: st.latest_vision.get(k)
                        for k in ("valid", "follow_wall", "front_wall", "wall_dist_px", "corner_hint")
                    },
                    "auto_running": st.auto_running,
                }
            await ws.send_json(payload)
            await asyncio.sleep(0.5)
    except WebSocketDisconnect:
        pass
    finally:
        st._clients.discard(ws)


def main() -> None:
    import uvicorn
    cfg_path = ROOT / "config.yaml"
    if not cfg_path.exists():
        cfg_path = ROOT / "config.yaml.example"
    with cfg_path.open("r", encoding="utf-8") as fp:
        cfg = yaml.safe_load(fp)
    host = cfg.get("server", {}).get("host", "0.0.0.0")
    port = int(cfg.get("server", {}).get("port", 8080))
    uvicorn.run("main:app", host=host, port=port, reload=False)


if __name__ == "__main__":
    main()
